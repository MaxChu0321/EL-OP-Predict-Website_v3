import pandas as pd
from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import ValidationError
from io import BytesIO
import joblib
import logging
import json
from setting import *
from scripts import parse_feature, get_derived_features, standardize_df, predict_ER, predict_surv, parse_feature_OP, get_derived_features_OP
from models import PatientData_ER, PatientData_Surv, PatientData_ER_OP

# Initial
## setup loggers
logging.config.fileConfig('logging.conf', disable_existing_loggers=False)
# get root logger
logger = logging.getLogger(__name__)
logger.info("Logging...")

logger.info("Import EL-RFA model...")
ELRFA_ER_cli_sEstimator = joblib.load(ELRFA_ER_cli_sMODEL)
ELRFA_ER_cli_bEstimator = joblib.load(ELRFA_ER_cli_bMODEL)
ELRFA_ER_cli_2DRad_sEstimator = joblib.load(ELRFA_ER_cli_2DRad_sMODEL)
ELRFA_ER_cli_2DRad_bEstimator = joblib.load(ELRFA_ER_cli_2DRad_bMODEL)
ELRFA_ER_cli_Rad_sEstimator = joblib.load(ELRFA_ER_cli_Rad_sMODEL)
ELRFA_ER_cli_Rad_bEstimator = joblib.load(ELRFA_ER_cli_Rad_bMODEL)
ELRFA_ER_cli_2DRad_DL_sEstimator = joblib.load(ELRFA_ER_cli_2DRad_DL_sMODEL)
ELRFA_ER_cli_2DRad_DL_bEstimator = joblib.load(ELRFA_ER_cli_2DRad_DL_bMODEL)
ELRFA_ER_cli_Rad_DL_sEstimator = joblib.load(ELRFA_ER_cli_Rad_DL_sMODEL)
ELRFA_ER_cli_Rad_DL_bEstimator = joblib.load(ELRFA_ER_cli_Rad_DL_bMODEL)
ELRFA_surv_cli_Estimator = joblib.load(ELRFA_surv_cli_MODEL)
ELRFA_surv_cli_2DRad_Estimator = joblib.load(ELRFA_surv_cli_2DRad_MODEL)
ELRFA_surv_cli_Rad_Estimator = joblib.load(ELRFA_surv_cli_Rad_MODEL)
ELRFA_surv_cli_2DRad_DL_Estimator = joblib.load(ELRFA_surv_cli_2DRad_DL_MODEL)
ELRFA_surv_cli_Rad_DL_Estimator = joblib.load(ELRFA_surv_cli_Rad_DL_MODEL)

logger.info("Get EL-RFA features...")
ELRFA_ER_cli_sFeatures = parse_feature(ELRFA_ER_cli_sEstimator)
ELRFA_ER_cli_bFeatures = parse_feature(ELRFA_ER_cli_bEstimator)
ELRFA_ER_cli_2DRad_sFeatures = parse_feature(ELRFA_ER_cli_2DRad_sEstimator)
ELRFA_ER_cli_2DRad_bFeatures = parse_feature(ELRFA_ER_cli_2DRad_bEstimator)
ELRFA_ER_cli_Rad_sFeatures = parse_feature(ELRFA_ER_cli_Rad_sEstimator)
ELRFA_ER_cli_Rad_bFeatures = parse_feature(ELRFA_ER_cli_Rad_bEstimator)
ELRFA_ER_cli_2DRad_DL_sFeatures = parse_feature(ELRFA_ER_cli_2DRad_DL_sEstimator)
ELRFA_ER_cli_2DRad_DL_bFeatures = parse_feature(ELRFA_ER_cli_2DRad_DL_bEstimator)
ELRFA_ER_cli_Rad_DL_sFeatures = parse_feature(ELRFA_ER_cli_Rad_DL_sEstimator)
ELRFA_ER_cli_Rad_DL_bFeatures = parse_feature(ELRFA_ER_cli_Rad_DL_bEstimator)
ELRFA_surv_cli_Features = parse_feature(ELRFA_surv_cli_Estimator)
ELRFA_surv_cli_2DRad_Features = parse_feature(ELRFA_surv_cli_2DRad_Estimator)
ELRFA_surv_cli_Rad_Features = parse_feature(ELRFA_surv_cli_Rad_Estimator)
ELRFA_surv_cli_2DRad_DL_Features = parse_feature(ELRFA_surv_cli_2DRad_DL_Estimator)
ELRFA_surv_cli_Rad_DL_Features = parse_feature(ELRFA_surv_cli_Rad_DL_Estimator)

logger.info("Import EL-OP model...")
ELOP_ER_cli = joblib.load(ELOP_ER_cli_MODEL)
ELOP_ER_multi = joblib.load(ELOP_ER_multi_MODEL)
logger.info("Get EL-OP features...")
ELOP_ER_cli_Features = parse_feature(ELOP_ER_cli)
ELOP_ER_multi_Features = parse_feature(ELOP_ER_multi)
logger.info("Initial API...")
app = FastAPI()

# CORS
origins = [
    "*"
    # "http://localhost:9000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logger.info("Initialization complete.")


# Views
@app.get("/api/test")
def test():
    return ELRFA_ER_cli_sFeatures

@app.post("/api/early_recurrence/submit/case")
async def submit(request: Request):
    results = None  # 初始化結果變量
    form_data = await request.form()
    data_dict = {key: value for key, value in form_data.items() if not isinstance(value, UploadFile)}
    file: UploadFile = form_data.get("file")

    try:
        patient_data = PatientData_ER(**data_dict)
        patient_data_OP = PatientData_ER_OP(**data_dict)
    except ValidationError as e:
        print("Validation Error:", e)
        return HTTPException(status_code=400, detail=f"Validation error: {e.errors()}")
        # return HTTPException(status_code=400, detail=f"Validation error: {e.errors()}")
    clinical_data_df = pd.DataFrame([patient_data.dict()])
    clinical_data_df_OP = pd.DataFrame([patient_data_OP.dict()])
    if file:
        file_contents = await file.read()
        try:
            if file.filename.endswith('.csv'):
                image_features_df = pd.read_csv( BytesIO( file_contents ) ).astype('float')
            elif file.filename.endswith(('.xls', '.xlsx', '.xlsm', '.xlsb')):
                image_features_df = pd.read_excel( BytesIO( file_contents ) ).astype('float')
            else:
                raise HTTPException(status_code=400, detail="Unsupported file format")
            
            complete_data_df = pd.concat([clinical_data_df, image_features_df], axis=1)
            complete_data_df_OP = pd.concat([clinical_data_df_OP, image_features_df], axis=1)
            if complete_data_df_OP is not None:
                try:
                    feature_df = get_derived_features_OP(complete_data_df_OP, ELOP_ER_multi_Features, CUTPOINTS_cli_OP)
                    std_feature_df = standardize_df(feature_df[ELOP_ER_multi.feature_names_in_], ELOP_ER_multi_SCALER)
                    results = predict_ER(ELOP_ER_multi, std_feature_df, RISK_THRESHOLD_multi_OP)
                except Exception as e:
                    print(f"Error in processing with `ELOP_ER_multi`: {e}")
            # elif complete_data_df.loc[0, 'Tumor size'] >= 2.5:
            #     try:
            #         feature_df = get_derived_features(complete_data_df, ELRFA_ER_cli_Rad_DL_bFeatures, CUTPOINTS)
            #         std_feature_df = standardize_df(feature_df[ELRFA_ER_cli_Rad_DL_bEstimator.feature_names_in_], ELRFA_ER_cli_Rad_DL_bSCALER)
            #         results = predict_ER(ELRFA_ER_cli_Rad_DL_bEstimator, std_feature_df, RISK_THRESHOLD_cli_Rad_DL_bER)
            #     except:
            #         try:
            #             feature_df = get_derived_features(complete_data_df, ELRFA_ER_cli_2DRad_DL_bFeatures, CUTPOINTS)
            #             std_feature_df = standardize_df(feature_df[ELRFA_ER_cli_2DRad_DL_bEstimator.feature_names_in_], ELRFA_ER_cli_2DRad_DL_bSCALER)
            #             results = predict_ER(ELRFA_ER_cli_2DRad_DL_bEstimator, std_feature_df, RISK_THRESHOLD_cli_2DRad_DL_bER)
            #         except:
            #             try:
            #                 feature_df = get_derived_features(complete_data_df, ELRFA_ER_cli_Rad_bFeatures, CUTPOINTS)
            #                 std_feature_df = standardize_df(feature_df[ELRFA_ER_cli_Rad_bEstimator.feature_names_in_], ELRFA_ER_cli_Rad_bSCALER)
            #                 results = predict_ER(ELRFA_ER_cli_Rad_bEstimator, std_feature_df, RISK_THRESHOLD_cli_Rad_bER)
            #             except:
            #                 try:
            #                     feature_df = get_derived_features(complete_data_df, ELRFA_ER_cli_2DRad_bFeatures, CUTPOINTS)
            #                     std_feature_df = standardize_df(feature_df[ELRFA_ER_cli_2DRad_bEstimator.feature_names_in_], ELRFA_ER_cli_2DRad_bSCALER)
            #                     results = predict_ER(ELRFA_ER_cli_2DRad_bEstimator, std_feature_df, RISK_THRESHOLD_cli_2DRad_bER)
            #                 except:
            #                     raise HTTPException(status_code=400, detail="Failed to use your image features.")
            # else:
            #     try:
            #         feature_df = get_derived_features(complete_data_df, ELRFA_ER_cli_Rad_DL_sFeatures, CUTPOINTS)
            #         std_feature_df = standardize_df(feature_df[ELRFA_ER_cli_Rad_DL_sEstimator.feature_names_in_], ELRFA_ER_cli_Rad_DL_sSCALER)
            #         results = predict_ER(ELRFA_ER_cli_Rad_DL_sEstimator, std_feature_df, RISK_THRESHOLD_cli_Rad_DL_sER)
            #     except:
            #         try:
            #             feature_df = get_derived_features(complete_data_df, ELRFA_ER_cli_2DRad_DL_sFeatures, CUTPOINTS)
            #             std_feature_df = standardize_df(feature_df[ELRFA_ER_cli_2DRad_DL_sEstimator.feature_names_in_], ELRFA_ER_cli_2DRad_DL_sSCALER)
            #             results = predict_ER(ELRFA_ER_cli_2DRad_DL_sEstimator, std_feature_df, RISK_THRESHOLD_cli_2DRad_DL_sER)
            #         except:
            #             try:
            #                 feature_df = get_derived_features(complete_data_df, ELRFA_ER_cli_Rad_sFeatures, CUTPOINTS)
            #                 std_feature_df = standardize_df(feature_df[ELRFA_ER_cli_Rad_sEstimator.feature_names_in_], ELRFA_ER_cli_Rad_sSCALER)
            #                 results = predict_ER(ELRFA_ER_cli_Rad_sEstimator, std_feature_df, RISK_THRESHOLD_cli_Rad_sER)
            #             except:
                            # try:
                            #     feature_df = get_derived_features(complete_data_df, ELRFA_ER_cli_2DRad_sFeatures, CUTPOINTS)
                            #     std_feature_df = standardize_df(feature_df[ELRFA_ER_cli_2DRad_sEstimator.feature_names_in_], ELRFA_ER_cli_2DRad_sSCALER)
                            #     results = predict_ER(ELRFA_ER_cli_2DRad_sEstimator, std_feature_df, RISK_THRESHOLD_cli_2DRad_sER)
                            # except:
                            #     raise HTTPException(status_code=400, detail="Failed to use your image features.")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error processing file: {str(e)}")
    else:
        if clinical_data_df_OP is not None:
            feature_df = get_derived_features_OP(clinical_data_df_OP, ELOP_ER_cli_Features, CUTPOINTS_cli_OP)
            std_feature_df = standardize_df(feature_df[ELOP_ER_cli.feature_names_in_], ELOP_ER_cli_SCALER)
            results = predict_ER(ELOP_ER_cli, std_feature_df, RISK_THRESHOLD_cli_OP)
        # elif clinical_data_df.loc[0, 'Tumor size'] >= 2.5:
        #     feature_df = get_derived_features(clinical_data_df, ELRFA_ER_cli_bFeatures, CUTPOINTS)
        #     std_feature_df = standardize_df(feature_df[ELRFA_ER_cli_bEstimator.feature_names_in_], ELRFA_ER_cli_bSCALER)
        #     results = predict_ER(ELRFA_ER_cli_bEstimator, std_feature_df, RISK_THRESHOLD_cli_OP)
        # else:
        #     feature_df = get_derived_features(clinical_data_df, ELRFA_ER_cli_sFeatures, CUTPOINTS)
        #     std_feature_df = standardize_df(feature_df[ELRFA_ER_cli_sEstimator.feature_names_in_], ELRFA_ER_cli_sSCALER)
        #     results = predict_ER(ELRFA_ER_cli_sEstimator, std_feature_df, RISK_THRESHOLD_cli_sER)
    if results is None:
        raise HTTPException(status_code=500, detail="Failed to generate results due to processing errors.")
    return results

@app.post("/api/overall_survival/submit/case")
async def submit(request: Request):
    form_data = await request.form()
    data_dict = {key: value for key, value in form_data.items() if not isinstance(value, UploadFile)}
    file: UploadFile = form_data.get("file")

    try:
        patient_data = PatientData_Surv(**data_dict)
    except ValidationError as e:
        return HTTPException(status_code=400, detail=f"Validation error: {e.errors()}")
    clinical_data_df = pd.DataFrame([patient_data.dict()])
    
    if file:
        file_contents = await file.read()
        try:
            if file.filename.endswith('.csv'):
                image_features_df = pd.read_csv( BytesIO( file_contents ) ).astype('float')
            elif file.filename.endswith(('.xls', '.xlsx', '.xlsm', '.xlsb')):
                image_features_df = pd.read_excel( BytesIO( file_contents ) ).astype('float')
            else:
                raise HTTPException(status_code=400, detail="Unsupported file format")
            
            complete_data_df = pd.concat([clinical_data_df, image_features_df], axis=1)
            
            try:
                feature_df = get_derived_features(complete_data_df, ELRFA_surv_cli_Rad_DL_Features, CUTPOINTS)
                std_feature_df = standardize_df(feature_df[ELRFA_surv_cli_Rad_DL_Estimator.feature_names_in_], ELRFA_surv_cli_Rad_DL_SCALER)
                results = predict_surv(ELRFA_surv_cli_Rad_DL_Estimator, std_feature_df, RISK_THRESHOLD_cli_Rad_DL_surv)
            except:
                try:
                    feature_df = get_derived_features(complete_data_df, ELRFA_surv_cli_2DRad_DL_Features, CUTPOINTS)
                    std_feature_df = standardize_df(feature_df[ELRFA_surv_cli_2DRad_DL_Estimator.feature_names_in_], ELRFA_surv_cli_2DRad_DL_SCALER)
                    results = predict_surv(ELRFA_surv_cli_2DRad_DL_Estimator, std_feature_df, RISK_THRESHOLD_cli_2DRad_DL_surv)
                except:
                    try:
                        feature_df = get_derived_features(complete_data_df, ELRFA_surv_cli_Rad_Features, CUTPOINTS)
                        std_feature_df = standardize_df(feature_df[ELRFA_surv_cli_Rad_Estimator.feature_names_in_], ELRFA_surv_cli_Rad_SCALER)
                        results = predict_surv(ELRFA_surv_cli_Rad_Estimator, std_feature_df, RISK_THRESHOLD_cli_Rad_surv)
                    except:
                        try:
                            feature_df = get_derived_features(complete_data_df, ELRFA_surv_cli_2DRad_Features, CUTPOINTS)
                            std_feature_df = standardize_df(feature_df[ELRFA_surv_cli_2DRad_Estimator.feature_names_in_], ELRFA_surv_cli_2DRad_SCALER)
                            results = predict_surv(ELRFA_surv_cli_2DRad_Estimator, std_feature_df, RISK_THRESHOLD_cli_2DRad_surv)
                        except:
                            raise HTTPException(status_code=400, detail="Failed to use your image features.")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error processing file: {str(e)}")
    else:
        feature_df = get_derived_features(clinical_data_df, ELRFA_surv_cli_Features, CUTPOINTS)
        std_feature_df = standardize_df(feature_df[ELRFA_surv_cli_Estimator.feature_names_in_], ELRFA_surv_cli_SCALER)
        results = predict_surv(ELRFA_surv_cli_Estimator, std_feature_df, RISK_THRESHOLD_cli_surv)
    
    return results

@app.post("/api/early_recurrence/submit/batch")
async def submit_batch(file: UploadFile):
    file_contents = await file.read()
    try:
        if file.filename.endswith('.csv'):
            data_df = pd.read_csv( BytesIO( file_contents ) ).astype('float')
        elif file.filename.endswith(('.xls', '.xlsx', '.xlsm', '.xlsb')):
            data_df = pd.read_excel( BytesIO( file_contents ) ).astype('float')
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format")
        
        if 'Tumor size' not in data_df.columns or data_df['Tumor size'].isnull().all():
            raise HTTPException(status_code=400, detail="Failed to use your features.")
        
        data_df_big = data_df[data_df['Tumor size'] >= 2.5]
        data_df_small = data_df[data_df['Tumor size'] < 2.5]
        results_big_df = pd.DataFrame()
        results_small_df = pd.DataFrame()
        
        if sum(data_df['Tumor size'] >= 2.5) > 0:
            try:
                feature_df_big = get_derived_features(data_df_big, ELRFA_ER_cli_Rad_DL_bFeatures, CUTPOINTS)
                std_feature_df_big = standardize_df(feature_df_big[ELRFA_ER_cli_Rad_DL_bEstimator.feature_names_in_], ELRFA_ER_cli_Rad_DL_bSCALER)
                results_big = predict_ER(ELRFA_ER_cli_Rad_DL_bEstimator, std_feature_df_big, RISK_THRESHOLD_cli_Rad_DL_bER, mode="batch")
                results_big_df = pd.DataFrame(results_big, index=data_df_big.index)
            except:
                try:
                    feature_df_big = get_derived_features(data_df_big, ELRFA_ER_cli_2DRad_DL_bFeatures, CUTPOINTS)
                    std_feature_df_big = standardize_df(feature_df_big[ELRFA_ER_cli_2DRad_DL_bEstimator.feature_names_in_], ELRFA_ER_cli_2DRad_DL_bSCALER)
                    results_big = predict_ER(ELRFA_ER_cli_2DRad_DL_bEstimator, std_feature_df_big, RISK_THRESHOLD_cli_2DRad_DL_bER, mode="batch")
                    results_big_df = pd.DataFrame(results_big, index=data_df_big.index)
                except:
                    try:
                        feature_df_big = get_derived_features(data_df_big, ELRFA_ER_cli_Rad_bFeatures, CUTPOINTS)
                        std_feature_df_big = standardize_df(feature_df_big[ELRFA_ER_cli_Rad_bEstimator.feature_names_in_], ELRFA_ER_cli_Rad_bSCALER)
                        results_big = predict_ER(ELRFA_ER_cli_Rad_bEstimator, std_feature_df_big, RISK_THRESHOLD_cli_Rad_bER, mode="batch")
                        results_big_df = pd.DataFrame(results_big, index=data_df_big.index)
                    except:
                        try:
                            feature_df_big = get_derived_features(data_df_big, ELRFA_ER_cli_2DRad_bFeatures, CUTPOINTS)
                            std_feature_df_big = standardize_df(feature_df_big[ELRFA_ER_cli_2DRad_bEstimator.feature_names_in_], ELRFA_ER_cli_2DRad_bSCALER)
                            results_big = predict_ER(ELRFA_ER_cli_2DRad_bEstimator, std_feature_df_big, RISK_THRESHOLD_cli_2DRad_bER, mode="batch")
                            results_big_df = pd.DataFrame(results_big, index=data_df_big.index)
                        except:
                            try:
                                feature_df_big = get_derived_features(data_df_big, ELRFA_ER_cli_bFeatures, CUTPOINTS)
                                std_feature_df_big = standardize_df(feature_df_big[ELRFA_ER_cli_bEstimator.feature_names_in_], ELRFA_ER_cli_bSCALER)
                                results_big = predict_ER(ELRFA_ER_cli_bEstimator, std_feature_df_big, RISK_THRESHOLD_cli_bER, mode="batch")
                                results_big_df = pd.DataFrame(results_big, index=data_df_big.index)
                            except:
                                raise HTTPException(status_code=400, detail="Failed to use your features.")

        if sum(data_df['Tumor size'] < 2.5) > 0:
            try:
                feature_df_small = get_derived_features(data_df_small, ELRFA_ER_cli_Rad_DL_sFeatures, CUTPOINTS)
                std_feature_df_small = standardize_df(feature_df_small[ELRFA_ER_cli_Rad_DL_sEstimator.feature_names_in_], ELRFA_ER_cli_Rad_DL_sSCALER)
                results_small = predict_ER(ELRFA_ER_cli_Rad_DL_sEstimator, std_feature_df_small, RISK_THRESHOLD_cli_Rad_DL_sER, mode="batch")
                results_small_df = pd.DataFrame(results_small, index=data_df_small.index)
            except:
                try:
                    feature_df_small = get_derived_features(data_df_small, ELRFA_ER_cli_2DRad_DL_sFeatures, CUTPOINTS)
                    std_feature_df_small = standardize_df(feature_df_small[ELRFA_ER_cli_2DRad_DL_sEstimator.feature_names_in_], ELRFA_ER_cli_2DRad_DL_sSCALER)
                    results_small = predict_ER(ELRFA_ER_cli_2DRad_DL_sEstimator, std_feature_df_small, RISK_THRESHOLD_cli_2DRad_DL_sER, mode="batch")
                    results_small_df = pd.DataFrame(results_small, index=data_df_small.index)
                except:
                    try:
                        feature_df_small = get_derived_features(data_df_small, ELRFA_ER_cli_Rad_sFeatures, CUTPOINTS)
                        std_feature_df_small = standardize_df(feature_df_small[ELRFA_ER_cli_Rad_sEstimator.feature_names_in_], ELRFA_ER_cli_Rad_sSCALER)
                        results_small = predict_ER(ELRFA_ER_cli_Rad_sEstimator, std_feature_df_small, RISK_THRESHOLD_cli_Rad_sER, mode="batch")
                        results_small_df = pd.DataFrame(results_small, index=data_df_small.index)
                    except:
                        try:
                            feature_df_small = get_derived_features(data_df_small, ELRFA_ER_cli_2DRad_sFeatures, CUTPOINTS)
                            std_feature_df_small = standardize_df(feature_df_small[ELRFA_ER_cli_2DRad_sEstimator.feature_names_in_], ELRFA_ER_cli_2DRad_sSCALER)
                            results_small = predict_ER(ELRFA_ER_cli_2DRad_sEstimator, std_feature_df_small, RISK_THRESHOLD_cli_2DRad_sER, mode="batch")
                            results_small_df = pd.DataFrame(results_small, index=data_df_small.index)
                        except:
                            try:
                                feature_df_small = get_derived_features(data_df_small, ELRFA_ER_cli_sFeatures, CUTPOINTS)
                                std_feature_df_small = standardize_df(feature_df_small[ELRFA_ER_cli_sEstimator.feature_names_in_], ELRFA_ER_cli_sSCALER)
                                results_small = predict_ER(ELRFA_ER_cli_sEstimator, std_feature_df_small, RISK_THRESHOLD_cli_sER, mode="batch")
                                results_small_df = pd.DataFrame(results_small, index=data_df_small.index)
                            except:
                                raise HTTPException(status_code=400, detail="Failed to use your features.")
        
        results_df = pd.concat([results_big_df, results_small_df]).sort_index()
        excel_file = BytesIO()
        results_df.to_excel(excel_file, index=False)
        excel_file.seek(0)
        response = StreamingResponse(excel_file, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        response.headers["Content-Disposition"] = "attachment; filename=results.xlsx"

        return response
    except Exception as e:
        return HTTPException(status_code=500, detail=str(e))

@app.post("/api/overall_survival/submit/batch")
async def submit_batch(file: UploadFile):
    file_contents = await file.read()
    try:
        if file.filename.endswith('.csv'):
            data_df = pd.read_csv( BytesIO( file_contents ) ).astype('float')
        elif file.filename.endswith(('.xls', '.xlsx', '.xlsm', '.xlsb')):
            data_df = pd.read_excel( BytesIO( file_contents ) ).astype('float')
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format")
        
        try:
            feature_df = get_derived_features(data_df, ELRFA_surv_cli_Rad_DL_Features, CUTPOINTS)
            std_feature_df = standardize_df(feature_df[ELRFA_surv_cli_Rad_DL_Estimator.feature_names_in_], ELRFA_surv_cli_Rad_DL_SCALER)
            results = predict_surv(ELRFA_surv_cli_Rad_DL_Estimator, std_feature_df, RISK_THRESHOLD_cli_Rad_DL_surv, mode="batch")
        except:
            try:
                feature_df = get_derived_features(data_df, ELRFA_surv_cli_2DRad_DL_Features, CUTPOINTS)
                std_feature_df = standardize_df(feature_df[ELRFA_surv_cli_2DRad_DL_Estimator.feature_names_in_], ELRFA_surv_cli_2DRad_DL_SCALER)
                results = predict_surv(ELRFA_surv_cli_2DRad_DL_Estimator, std_feature_df, RISK_THRESHOLD_cli_2DRad_DL_surv, mode="batch")
            except:
                try:
                    feature_df = get_derived_features(data_df, ELRFA_surv_cli_Rad_Features, CUTPOINTS)
                    std_feature_df = standardize_df(feature_df[ELRFA_surv_cli_Rad_Estimator.feature_names_in_], ELRFA_surv_cli_Rad_SCALER)
                    results = predict_surv(ELRFA_surv_cli_Rad_Estimator, std_feature_df, RISK_THRESHOLD_cli_Rad_surv, mode="batch")
                except:
                    try:
                        feature_df = get_derived_features(data_df, ELRFA_surv_cli_2DRad_Features, CUTPOINTS)
                        std_feature_df = standardize_df(feature_df[ELRFA_surv_cli_2DRad_Estimator.feature_names_in_], ELRFA_surv_cli_2DRad_SCALER)
                        results = predict_surv(ELRFA_surv_cli_2DRad_Estimator, std_feature_df, RISK_THRESHOLD_cli_2DRad_surv, mode="batch")
                    except:
                        try:
                            feature_df = get_derived_features(data_df, ELRFA_surv_cli_Features, CUTPOINTS)
                            std_feature_df = standardize_df(feature_df[ELRFA_surv_cli_Estimator.feature_names_in_], ELRFA_surv_cli_SCALER)
                            results = predict_surv(ELRFA_surv_cli_Estimator, std_feature_df, RISK_THRESHOLD_cli_surv, mode="batch")
                        except:
                            raise HTTPException(status_code=400, detail="Failed to use your features.")
        
        results_df = pd.DataFrame(results)
        excel_file = BytesIO()
        results_df.to_excel(excel_file, index=False)
        excel_file.seek(0)
        response = StreamingResponse(excel_file, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        response.headers["Content-Disposition"] = "attachment; filename=results.xlsx"

        return response
    except Exception as e:
        return HTTPException(status_code=500, detail=str(e))