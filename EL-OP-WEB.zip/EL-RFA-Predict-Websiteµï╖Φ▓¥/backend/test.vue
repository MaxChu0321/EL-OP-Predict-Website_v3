<q-input outlined type="number" v-model="form.afp" label="AFP" />
<q-input outlined type="number" v-model="form.alb" label="ALB" />
<q-input outlined type="number" v-model="form.tumor_size" label="Tumor size" />
<q-input outlined type="number" v-model="form.uptoscore" label="UpToScore" />
<q-input outlined type="number" v-model="form.fib4" label="FIB4" />
<q-input outlined type="number" v-model="form.age" label="Age" />
<q-input outlined type="number" v-model="form.tumor_counts" label="Tumor counts" />
<q-input outlined type="number" v-model="form.cr" label="CR" />
<q-input outlined type="number" v-model="form.hcv" label="HCV" />
<q-input outlined type="number" v-model="form.fib4stage" label="FIB4stage" />
<q-input outlined type="number" v-model="form.ast" label="AST" />
<q-input outlined type="number" v-model="form.bun" label="BUN" />
<q-input outlined type="number" v-model="form.alt" label="ALT" />
<q-input outlined type="number" v-model="form.bili" label="BILI" />
<q-input outlined type="number" v-model="form.bclc_stage" label="BCLC stage" />

